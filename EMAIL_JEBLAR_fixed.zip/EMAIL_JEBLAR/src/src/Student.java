package src;

public class Student {
    private String studentID;
    private String firstName;
    private String lastName;
    private String major;
    private String year;
    private String email;

    public Student(String studentID, String firstName, String lastName, String major, String year, String email) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.major = major;
        this.year = year;
        this.email = email;
    }

    // Hanya getter untuk Email dan Tahun yang diperlukan untuk filtering
    public String getEmail() {
        return email;
    }

    public String getYear() {
        return year;
    }
    
    // Untuk tampilan di GUI
    @Override
    public String toString() {
        return studentID + " | " + firstName + " " + lastName + " | " + major + " | " + year + " | " + email;
    }
}