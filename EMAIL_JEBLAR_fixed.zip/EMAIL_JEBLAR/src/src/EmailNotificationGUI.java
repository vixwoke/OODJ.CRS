package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EmailNotificationGUI extends JFrame implements ActionListener {

    private static final String FILE_NAME = "student_information (1).csv"; // Path Relatif
    private JTextArea outputArea;
    private JButton loadButton;
    private JButton notifyButton;
    private List<Student> allStudents;

    public EmailNotificationGUI() {
        // --- Konfigurasi Jendela Utama ---
        setTitle("Sistem Notifikasi Email Akademik");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // --- Inisialisasi Komponen ---
        allStudents = new ArrayList<>();
        outputArea = new JTextArea("Tekan 'Muat Data Mahasiswa' untuk memulai.\n", 25, 60);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        loadButton = new JButton("1. Muat Data Mahasiswa");
        notifyButton = new JButton("2. Kirim Notifikasi (Mahasiswa Senior)");
        notifyButton.setEnabled(false); // Nonaktifkan sampai data dimuat

        // --- Panel Kontrol (Atas) ---
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        controlPanel.add(loadButton);
        controlPanel.add(notifyButton);
        
        // --- Tambahkan ke Frame ---
        add(controlPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // --- Tambahkan Listener ---
        loadButton.addActionListener(this);
        notifyButton.addActionListener(this);
        
        setVisible(true);
    }

    // --- Implementasi Pembacaan CSV (Inti Logika Data) ---
    private void loadStudentsFromCSV() {
        allStudents.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            boolean isHeader = true;
            int studentCount = 0;

            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                
                String[] columns = line.split(",", -1); // Split semua kolom, termasuk yang kosong
                
                if (columns.length >= 6) { // Memastikan semua kolom utama ada
                    try {
                        // Kolom: StudentID,FirstName,LastName,Major,Year,Email
                        Student student = new Student(
                            columns[0].trim(), columns[1].trim(), columns[2].trim(),
                            columns[3].trim(), columns[4].trim(), columns[5].trim()
                        );
                        allStudents.add(student);
                        studentCount++;
                    } catch (ArrayIndexOutOfBoundsException e) {
                        outputArea.append("Error parsing line: " + line + "\n");
                    }
                }
            }

            outputArea.append("\n============================================\n");
            outputArea.append("✅ Data Berhasil Dimuat!\n");
            outputArea.append("Total Mahasiswa Terdaftar: " + studentCount + "\n");
            outputArea.append("============================================\n");
            notifyButton.setEnabled(true);
            
        } catch (IOException e) {
            outputArea.append("\n❌ GAGAL MEMBACA FILE:\n");
            outputArea.append("Pastikan file '" + FILE_NAME + "' berada di folder root proyek.\n");
            notifyButton.setEnabled(false);
        }
    }
    
    // --- Implementasi Simulasi Notifikasi Email ---
    private void sendAcademicPerformanceNotification() {
        if (allStudents.isEmpty()) {
            outputArea.append("\n[SIMULASI GAGAL] Tidak ada data mahasiswa yang dimuat.\n");
            return;
        }

        // Contoh: Mengirim Laporan Kinerja Akademik (Academic performance report) hanya kepada Mahasiswa Senior
        Set<String> recipients = new HashSet<>();
        
        for (Student student : allStudents) {
            // Logika Notifikasi berdasarkan instruksi: "Academic performance report"
            // Kita filter hanya untuk mahasiswa Tahun "Senior"
            if (student.getYear().equalsIgnoreCase("Senior")) {
                recipients.add(student.getEmail());
            }
        }
        
        outputArea.append("\n============================================\n");
        outputArea.append("📨 SIMULASI PENGIRIMAN NOTIFIKASI EMAIL\n");
        outputArea.append("Tipe Notifikasi: Laporan Kinerja Akademik\n");
        outputArea.append("Target Penerima: Mahasiswa Senior\n");
        outputArea.append("--------------------------------------------\n");
        outputArea.append("Total Mahasiswa Senior yang Akan Menerima Notifikasi: " + recipients.size() + "\n");
        outputArea.append("Daftar Email Penerima Unik (Simulasi):\n");
        
        int count = 1;
        for (String email : recipients) {
            outputArea.append("  " + count + ". " + email + "\n");
            count++;
        }
        outputArea.append("============================================\n");
        outputArea.append("Simulasi Selesai. Notifikasi berhasil dikirim ke " + recipients.size() + " alamat email unik.\n");
    }

    // --- Event Handling untuk Tombol ---
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loadButton) {
            loadStudentsFromCSV();
        } else if (e.getSource() == notifyButton) {
            sendAcademicPerformanceNotification();
        }
    }

    public static void main(String[] args) {
        // Menjalankan GUI di Event Dispatch Thread (standar Swing)
        SwingUtilities.invokeLater(() -> new EmailNotificationGUI());
    }
}